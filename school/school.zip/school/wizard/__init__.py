# See LICENSE file for full copyright and licensing details.


from . import move_standards
from . import wiz_send_email
from . import teriminate_reason
from . import add_student
from . import report_statistic_descipline
from . import wizard_setting_descipline

